import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import { toast } from 'sonner'
import { getUniqueSelector, resolve } from '@/lib/selector-engine'
import * as preview from '@/lib/preview'
import { store } from '@/hooks/use-annotations'
import { formatReset } from '@/lib/annotation-quota'
import { goToPricing } from '@/context/subscription-context'
import type { Annotation } from '@/lib/types'

/* ─────────────────────────────────────────────────────────────────────────
   AnnotationUIContext — shared UI state for the annotation layer: which card
   is open (saved view vs unsaved draft), sidebar/share visibility, the shared
   author name, and the "focus/flash an element" action used by pins + list.
───────────────────────────────────────────────────────────────────────── */

interface AnnotationUIValue {
  // Card
  activeId: string | null
  draft: Annotation | null
  cardOpen: boolean
  openCard: (id: string) => void
  // Open a saved annotation's card with the comment editor already active.
  openCardForEdit: (id: string) => void
  editIntentId: string | null
  clearEditIntent: () => void
  openDraft: (el: Element) => void
  updateDraft: (patch: Partial<Annotation>) => void
  submitDraft: () => void
  closeCard: () => void
  // Sidebar
  sidebarOpen: boolean
  toggleSidebar: () => void
  openSidebar: () => void
  closeSidebar: () => void
  // Author (mirrored between toolbar + panel name fields)
  author: string
  setAuthor: (v: string) => void
  // Re-link an orphaned annotation to a freshly-picked element
  relinkId: string | null
  startRelink: (id: string) => void
  cancelRelink: () => void
  completeRelink: (el: Element) => void
  // Focus/flash an element on the page
  flashEl: Element | null
  focusAnnotation: (ann: Annotation) => void
  // Transient highlight when hovering a pin (works in client mode too)
  hoverPinEl: Element | null
  setHoverPinEl: (el: Element | null) => void
}

const AnnotationUIContext = createContext<AnnotationUIValue | null>(null)

export function AnnotationUIProvider({ children }: { children: ReactNode }) {
  const [activeId, setActiveId] = useState<string | null>(null)
  const [editIntentId, setEditIntentId] = useState<string | null>(null)
  const [draft, setDraft] = useState<Annotation | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [author, setAuthor] = useState('')
  const [flashEl, setFlashEl] = useState<Element | null>(null)
  const [hoverPinEl, setHoverPinEl] = useState<Element | null>(null)
  const [relinkId, setRelinkId] = useState<string | null>(null)
  const flashTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const relinkIdRef = useRef(relinkId)
  relinkIdRef.current = relinkId
  const authorRef = useRef(author)
  authorRef.current = author
  // Refs mirror state so callbacks can run store/preview side effects directly
  // (never inside a setState updater, which would run during render).
  const draftRef = useRef(draft)
  draftRef.current = draft
  const activeIdRef = useRef(activeId)
  activeIdRef.current = activeId

  const closeCard = useCallback(() => {
    const d = draftRef.current
    if (d) preview.revert(d.id)
    const id = activeIdRef.current
    // Safety net: drop a submitted annotation the user emptied out.
    if (id != null && store.getRole() === 'author') {
      const ann = store.get(id)
      if (ann && !ann.comment.trim()) {
        preview.revert(id)
        store.remove(id)
      }
    }
    setDraft(null)
    setActiveId(null)
  }, [])

  const openCard = useCallback((id: string) => {
    const d = draftRef.current
    if (d) preview.revert(d.id)
    setDraft(null)
    setEditIntentId(null)
    setActiveId(id)
  }, [])

  const openCardForEdit = useCallback((id: string) => {
    const d = draftRef.current
    if (d) preview.revert(d.id)
    setDraft(null)
    setEditIntentId(id)
    setActiveId(id)
  }, [])

  const clearEditIntent = useCallback(() => setEditIntentId(null), [])

  const openDraft = useCallback((el: Element) => {
    // Per-domain / 24h annotation cap (Free 3 / Pro 10 / Max unlimited). Block
    // starting a new draft when at the cap and nudge to upgrade, rather than
    // letting the store silently drop it on submit.
    if (!store.canAddAnnotation()) {
      const { limit, resetsInMs } = store.annotationQuota()
      const resetTxt =
        resetsInMs != null ? ` Try again in ~${formatReset(resetsInMs)}.` : ''
      // Custom Sparrow-themed CTA (not sonner's default action button, whose
      // dark styling out-specifies our utilities). Dismiss the toast, then route
      // to the pricing cards (extension → opens the web app; see goToPricing).
      let toastId: string | number = ''
      toastId = toast(
        `You've reached your limit of ${limit} annotation${limit === 1 ? '' : 's'} for this site.${resetTxt}`,
        {
          // `annot-limit-toast` paints the reddish "quota expired" alert look
          // (styled in index.css); the warning glyph is an inline SVG so it needs
          // no icon-lib import and inherits the alert red via currentColor.
          className: 'annot-limit-toast',
          icon: (
            <svg
              viewBox="0 0 24 24"
              width="18"
              height="18"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z" />
              <line x1="12" x2="12" y1="9" y2="13" />
              <line x1="12" x2="12.01" y1="17" y2="17" />
            </svg>
          ),
          action: (
            <button
              type="button"
              className="annot-upgrade-btn"
              onClick={() => {
                toast.dismiss(toastId)
                goToPricing()
              }}
            >
              Upgrade
            </button>
          ),
        },
      )
      return
    }
    const prev = draftRef.current
    if (prev) preview.revert(prev.id)
    setDraft({
      id: store.newId(),
      pageUrl: '',
      selector: getUniqueSelector(el),
      comment: '',
      category: 'General',
      status: 'Open',
      author: authorRef.current.trim(),
      createdAt: '',
      styling: store.defaultStyling(),
      suggestedChanges: {},
      replies: [],
    })
    setActiveId(null)
  }, [])

  const updateDraft = useCallback((patch: Partial<Annotation>) => {
    setDraft((d) => (d ? { ...d, ...patch } : d))
  }, [])

  const submitDraft = useCallback(() => {
    const d = draftRef.current
    if (!d) return
    preview.revert(d.id)
    store.add({
      selector: d.selector,
      comment: d.comment,
      category: d.category,
      author: d.author,
      styling: d.styling,
      suggestedChanges: d.suggestedChanges,
    })
    setDraft(null)
    setActiveId(null)
  }, [])

  const toggleSidebar = useCallback(() => setSidebarOpen((o) => !o), [])
  const openSidebar = useCallback(() => setSidebarOpen(true), [])
  const closeSidebar = useCallback(() => setSidebarOpen(false), [])

  const flashElement = useCallback((el: Element) => {
    el.scrollIntoView({ behavior: 'smooth', block: 'center' })
    if (flashTimer.current) clearTimeout(flashTimer.current)
    setFlashEl(el)
    flashTimer.current = setTimeout(() => setFlashEl(null), 1600)
  }, [])

  const focusAnnotation = useCallback(
    (ann: Annotation) => {
      const el = resolve(ann.selector)
      if (el) flashElement(el)
    },
    [flashElement],
  )

  // Re-link: enter a "pick a new element" mode for an existing annotation, then
  // rewrite its stored selector to whatever element the user clicks next. Used
  // to rescue orphaned annotations whose original element moved or changed.
  const startRelink = useCallback((id: string) => {
    const d = draftRef.current
    if (d) preview.revert(d.id)
    setDraft(null)
    setActiveId(null)
    setRelinkId(id)
  }, [])

  const cancelRelink = useCallback(() => setRelinkId(null), [])

  const completeRelink = useCallback(
    (el: Element) => {
      const id = relinkIdRef.current
      if (!id) return
      store.update(id, { selector: getUniqueSelector(el) })
      setRelinkId(null)
      flashElement(el)
    },
    [flashElement],
  )

  const value = useMemo<AnnotationUIValue>(
    () => ({
      activeId,
      draft,
      cardOpen: activeId != null || draft != null,
      openCard,
      openCardForEdit,
      editIntentId,
      clearEditIntent,
      openDraft,
      updateDraft,
      submitDraft,
      closeCard,
      sidebarOpen,
      toggleSidebar,
      openSidebar,
      closeSidebar,
      author,
      setAuthor,
      relinkId,
      startRelink,
      cancelRelink,
      completeRelink,
      flashEl,
      focusAnnotation,
      hoverPinEl,
      setHoverPinEl,
    }),
    [
      activeId,
      draft,
      openCard,
      openCardForEdit,
      editIntentId,
      clearEditIntent,
      openDraft,
      updateDraft,
      submitDraft,
      closeCard,
      sidebarOpen,
      toggleSidebar,
      openSidebar,
      closeSidebar,
      author,
      relinkId,
      startRelink,
      cancelRelink,
      completeRelink,
      flashEl,
      focusAnnotation,
      hoverPinEl,
    ],
  )

  return (
    <AnnotationUIContext value={value}>{children}</AnnotationUIContext>
  )
}

export function useAnnotationUI(): AnnotationUIValue {
  const ctx = useContext(AnnotationUIContext)
  if (!ctx)
    throw new Error('useAnnotationUI must be used within AnnotationUIProvider')
  return ctx
}

import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { LogOut, Menu, X } from 'lucide-react'
import sparrowLogo from '@/assets/sparrow-logo.png'
import { ArrowButton } from './parts'
import { useAuth } from '@/context/auth-context'
import { cn } from '@/lib/format'

const NAV = [
  { label: 'Home', href: '#home' },
  { label: 'How it works', href: '#how-it-works' },
  { label: 'Features', href: '#features' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'FAQ', href: '#faq' },
]

const CONTACT_EMAIL = 'hello@trysparrowcss.com'

export function LandingHeader() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { openLoginDialog, isAuthenticated, signOut } = useAuth()
  const navigate = useNavigate()
  const { pathname } = useLocation()

  // Reused on /account, /privacy, /terms too. Those pages don't carry the
  // landing sections, so the anchors (#home, #features …) must point back at the
  // landing page ("/#features") rather than scroll in place. `onAccount` also
  // swaps the right-side CTA to Sign out (you're already on your account).
  const onAccount = pathname.startsWith('/account')
  const onLanding = pathname === '/'
  const navBase = onLanding ? '' : '/'
  const handleSignOut = () => void signOut().then(() => navigate('/'))

  // On the landing page, smooth-scroll to the section without letting the
  // browser append the "#home"/"#features" hash to the URL. On the other pages
  // the anchors navigate client-side to the landing page, where RouterBridge
  // scrolls to the target section once it mounts.
  const handleNavClick = (href: string) => (e: React.MouseEvent) => {
    e.preventDefault()
    setOpen(false)
    if (!onLanding) {
      navigate(`/${href}`) // e.g. "/#features"
      return
    }
    document.getElementById(href.slice(1))?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      id="landing-header"
      className={cn(
        'fixed inset-x-0 top-0 z-50 px-4 md:px-8',
        'transition-[padding] duration-300 ease-out',
        scrolled ? 'pt-2' : 'pt-4',
      )}
    >
      <nav
        aria-label="Primary"
        className={cn(
          'mx-auto flex items-center justify-between rounded-[15px] backdrop-blur-xl backdrop-saturate-[180%]',
          'transition-[max-width,padding,background-color,box-shadow] duration-300 ease-out',
          // At the very top the pill blends into the hero's sky — no white box,
          // ring, or shadow. Once scrolled it lifts into a frosted white pill so
          // it stays legible over the content passing beneath it.
          scrolled
            ? 'max-w-[1120px] bg-white/75 px-4 py-2 pb-[14px] shadow-lg shadow-black/5 ring-1 ring-black/[0.06] md:px-3'
            : 'max-w-[1280px] bg-transparent px-5 py-3 md:px-4',
        )}
      >
        <div className="flex items-center gap-10">
          <a
            href={`${navBase}#home`}
            onClick={handleNavClick('#home')}
            aria-label="Sparrow home"
          >
            <img
              src={sparrowLogo}
              alt="Sparrow"
              draggable={false}
              className="h-14 w-auto"
            />
          </a>

          {/* Desktop nav — revealed at lg; below that the 5 links + Sign-in
              button don't fit the pill without wrapping, so tablets get the
              hamburger menu instead. */}
          <ul className="hidden items-center gap-8 lg:flex">
            {NAV.map((item) => (
              <li key={item.label}>
                <a
                  href={`${navBase}${item.href}`}
                  onClick={handleNavClick(item.href)}
                  className="font-abeezee text-base font-semibold text-sparrow-ink/90 transition-colors hover:text-sparrow-blue"
                >
                  {item.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href={`mailto:${CONTACT_EMAIL}`}
                className="font-abeezee text-base font-semibold text-sparrow-ink/90 transition-colors hover:text-sparrow-blue"
              >
                Contact
              </a>
            </li>
          </ul>
        </div>

        <div className="flex items-center gap-2">
          {onAccount && isAuthenticated ? (
            <button
              type="button"
              onClick={handleSignOut}
              className="cursor-pointer hidden items-center gap-1.5 rounded-[10px] px-4 py-2 font-abeezee text-sm font-semibold text-sparrow-ink transition-colors hover:bg-black/5 lg:inline-flex"
            >
              <LogOut className="size-4" />
              Sign out
            </button>
          ) : isAuthenticated ? (
            <ArrowButton
              variant="blue"
              href="/account"
              className="hidden px-4 py-2 text-sm lg:inline-flex [&_svg]:size-4"
            >
              My account
            </ArrowButton>
          ) : (
            <ArrowButton
              variant="blue"
              onClick={openLoginDialog}
              className="hidden px-4 py-2 text-sm lg:inline-flex [&_svg]:size-4"
            >
              Sign in
            </ArrowButton>
          )}
          <button
            type="button"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            aria-controls="landing-mobile-menu"
            onClick={() => setOpen((v) => !v)}
            className="inline-flex size-10 items-center justify-center rounded-[10px] text-sparrow-ink hover:bg-black/5 lg:hidden"
          >
            {open ? <X className="size-6" /> : <Menu className="size-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        id="landing-mobile-menu"
        className={cn(
          'mx-auto mt-2 max-w-[1680px] overflow-hidden rounded-[15px] border border-black/5 bg-white/80 backdrop-blur-xl backdrop-saturate-[180%] transition-all lg:hidden',
          open ? 'max-h-96 opacity-100' : 'pointer-events-none max-h-0 border-transparent opacity-0',
        )}
      >
        <ul className="flex flex-col gap-1 p-4">
          {NAV.map((item) => (
            <li key={item.label}>
              <a
                href={`${navBase}${item.href}`}
                onClick={(e) => {
                  setOpen(false)
                  handleNavClick(item.href)(e)
                }}
                className="block rounded-lg px-3 py-2 font-abeezee text-base font-semibold text-sparrow-ink hover:bg-black/5"
              >
                {item.label}
              </a>
            </li>
          ))}
          <li>
            <a
              href={`mailto:${CONTACT_EMAIL}`}
              onClick={() => setOpen(false)}
              className="block rounded-lg px-3 py-2 font-abeezee text-base font-semibold text-sparrow-ink hover:bg-black/5"
            >
              Contact
            </a>
          </li>
          <li>
            {onAccount && isAuthenticated ? (
              <button
                type="button"
                onClick={() => {
                  setOpen(false)
                  handleSignOut()
                }}
                className="cursor-pointer mt-1 inline-flex w-full items-center justify-center gap-1.5 rounded-[10px] px-4 py-2.5 font-abeezee text-sm font-semibold text-sparrow-ink ring-1 ring-inset ring-black/10 hover:bg-black/5"
              >
                <LogOut className="size-4" />
                Sign out
              </button>
            ) : isAuthenticated ? (
              <ArrowButton
                variant="blue"
                href="/account"
                className="mt-1 w-full"
              >
                My account
              </ArrowButton>
            ) : (
              <ArrowButton
                variant="blue"
                onClick={() => {
                  setOpen(false)
                  openLoginDialog()
                }}
                className="mt-1 w-full"
              >
                Sign in
              </ArrowButton>
            )}
          </li>
        </ul>
      </div>
    </header>
  )
}
